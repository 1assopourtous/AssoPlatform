package com.example.asso_platform

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
