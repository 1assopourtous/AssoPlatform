import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';                        // 💡 Не забудь!
import 'package:asso_platform/l10n/app_localizations.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final texts = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(title: Text(texts.appTitle)),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              texts.welcomeHeadline,
              style: const TextStyle(fontSize: 24),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () => context.go('/auth'),  // 💚 Переход через GoRouter
              child: Text(texts.login),              // 🔄 используем перевод (или просто: Text('Войти'))
            ),
          ],
        ),
      ),
    );
  }
}
