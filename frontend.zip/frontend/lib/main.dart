// frontend/lib/main.dart

import 'dart:html'; // 

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_web_plugins/flutter_web_plugins.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_strategy/url_strategy.dart';
import 'package:flutter/foundation.dart';

import 'router.dart';
import 'l10n/app_localizations.dart';

// 💡 Автоматическое определение baseUrl
final baseUrl = kReleaseMode
    ? 'https://assopourtous.com/' // Production
    : window.location.origin;  // Dev: http://localhost:5173 и др.

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 1. .env
  await dotenv.load(fileName: '.env');
  final supabaseUrl = dotenv.env['SUPABASE_URL']!;
  final supabaseKey = dotenv.env['SUPABASE_ANON_KEY']!;

  // 2. Supabase
  await Supabase.initialize(
    url: supabaseUrl,
    anonKey: supabaseKey,
  );

  // 3. Чистые ссылки без #/
  setPathUrlStrategy();

  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late final _router = createRouter();
  Locale _locale = const Locale('en');

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'Platform',
      theme: ThemeData(
        primaryColor: const Color(0xFF2E7D32),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2E7D32)),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF2E7D32)),
        ),
      ),
      locale: _locale,
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ],
      supportedLocales: const [Locale('en'), Locale('fr')],
      routerConfig: _router,
      builder: (context, child) => Scaffold(
        body: Column(
          children: [
            _TopBar(
              locale: _locale,
              onLocaleChange: (l) => setState(() => _locale = l),
            ),
            Expanded(child: child ?? const SizedBox()),
          ],
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  final Locale locale;
  final void Function(Locale) onLocaleChange;
  const _TopBar({required this.locale, required this.onLocaleChange});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Theme.of(context).primaryColor,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          const Text('Platform', style: TextStyle(color: Colors.white, fontSize: 18)),
          const Spacer(),
          DropdownButton<Locale>(
            value: locale,
            dropdownColor: Colors.white,
            onChanged: (l) => onLocaleChange(l!),
            items: const [
              DropdownMenuItem(value: Locale('en'), child: Text('EN')),
              DropdownMenuItem(value: Locale('fr'), child: Text('FR')),
            ],
          ),
        ],
      ),
    );
  }
}
